# socialfixerdata
JSON Data used by Social Fixer
